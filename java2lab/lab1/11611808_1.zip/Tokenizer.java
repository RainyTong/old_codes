
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class Tokenizer {
	String filename;
	String FileContent;
	char[] contentArray;
	ArrayList<String> all;

	Tokenizer(String name){
		filename = name;
		FileContent = "";
		contentArray = null;
		all = new ArrayList();

		this.allConvertToString();
		this.stringToCharArray();
		this.putIntoArrayList();

	}


	public String nextToken(){
		if(all.size() == 0){
			return null;
		}
		String next = all.get(0);
		all.remove(0);
		return next;
	}

	public void allConvertToString(){

		try {
			FileInputStream fis = null;
			fis = new FileInputStream(filename);
			InputStreamReader isr = null;
			isr = new InputStreamReader(fis, "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			String line ;
			while ((line = br.readLine()) != null) {
			      FileContent += line;
			  }
			if(FileContent.startsWith("\uFEFF")){
				FileContent = FileContent.replace("\uFEFF","");
			}


		} catch (FileNotFoundException e) {
			System.out.println("Sorry, the file isn't found. Please check the file's name and whether it exists. And check if the path is an absolute one. Then try again.");
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			System.out.println("There is an unsupported encoding exception. Please check whether the file is in UTF-8. Check where goes wrong and try again.");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("There is an IO exception. Please check where goes wrong and try again.");
			e.printStackTrace();
		}

	}

	public void stringToCharArray(){
		contentArray = FileContent.toCharArray();
	}

	public void putIntoArrayList(){
		String tmp = "";
		String lowerCase;
		for(int i = 0; i < contentArray.length; i++){

			if(Character.isLetterOrDigit(contentArray[i])){
				if(Character.isUpperCase(contentArray[i])){
					lowerCase = String.valueOf(contentArray[i]).toLowerCase();
					contentArray[i] = lowerCase.charAt(0);
				}
				tmp += contentArray[i];
			}else if(contentArray[i] == '\'' && Character.isLetterOrDigit(contentArray[i-1]) == true && Character.isLetterOrDigit(contentArray[i+1]) == true){
				tmp += contentArray[i];
		}else{
			if(tmp != "")
			all.add(tmp);
			tmp="";
		}

	}


}



}
